<h2> Codecademy Answers </h2>

<h3> Python & Ruby </h3>

If you are currently improving your Ruby or Python programming skills through Codecademy the solutions I wrote in my spare time are for the exercises you are having hard times with. That's the reason besides fully completed answers you will find some incompleted ones. However they all would still pass the exercises. Unless your current exercise is impossible to pass without any help, it's not recommended to copy and past them.
